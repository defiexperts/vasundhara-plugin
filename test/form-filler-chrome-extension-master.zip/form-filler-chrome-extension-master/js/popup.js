// Simply open options page
chrome.runtime.openOptionsPage()
window.close()